(() => {
  // Version sans écran de connexion ni création de compte.
  const siteApp = document.getElementById('siteApp');
  if (siteApp) siteApp.hidden = false;

  document.getElementById('menuButton').addEventListener('click', () => document.body.classList.toggle('menu-open'));
  document.querySelectorAll('.nav-link').forEach(a => a.addEventListener('click', () => document.body.classList.remove('menu-open')));

  const lookupButton = document.getElementById('lookupButton');
  if (lookupButton) {
    const lookupType = document.getElementById('lookupType');
    const lookupQuery = document.getElementById('lookupQuery');
    const lookupMessage = document.getElementById('lookupMessage');
    const runLookup = () => {
      const type = lookupType.value;
      const raw = lookupQuery.value.trim();
      if (!raw) {
        lookupMessage.textContent = 'Saisis un terme de recherche.';
        lookupQuery.focus();
        return;
      }
      if (raw.length > 200) {
        lookupMessage.textContent = 'La recherche est trop longue.';
        return;
      }
      let url = '';
      const q = encodeURIComponent(raw);
      if (type === 'domain') {
        const domain = raw.replace(/^https?:\/\//i, '').split('/')[0];
        url = 'https://lookup.icann.org/en/lookup?name=' + encodeURIComponent(domain);
      } else if (type === 'ip') {
        url = 'https://www.virustotal.com/gui/ip-address/' + encodeURIComponent(raw);
      } else if (type === 'username') {
        url = 'https://www.google.com/search?q=' + encodeURIComponent('"' + raw + '" profile OR username');
      } else if (type === 'email') {
        url = 'https://haveibeenpwned.com/';
        lookupMessage.textContent = 'Ouvre le service puis saisis uniquement une adresse email que tu es autorisé à vérifier.';
      } else if (type === 'phone') {
        url = 'https://www.google.com/search?q=' + encodeURIComponent('"' + raw + '"');
        lookupMessage.textContent = 'La recherche ouvre des résultats web publics. N’utilise que des numéros que tu es autorisé à rechercher.';
      }
      if (type !== 'email' && type !== 'phone') lookupMessage.textContent = 'Ouverture d’un service public externe. Les résultats dépendent du service choisi.';
      if (url) window.open(url, '_blank', 'noopener,noreferrer');
    };
    lookupButton.addEventListener('click', runLookup);
    lookupQuery.addEventListener('keydown', event => { if (event.key === 'Enter') runLookup(); });
  }

  document.getElementById('searchForm').addEventListener('submit', event => {
    event.preventDefault();
    const q = document.getElementById('searchInput').value.trim().toLowerCase();
    let n = 0;
    document.querySelectorAll('.category-card,.recommended-card').forEach(card => {
      const match = !q || card.textContent.toLowerCase().includes(q);
      card.hidden = !match; if (match) n++;
    });
    if (!q) return;
    alert(n ? `${n} ressource(s) trouvée(s).` : 'Aucune ressource correspondante.');
  });
})();