NEXUS SHADOW — AUTHENTIFICATION SÉCURISÉE (squelette à configurer)

IMPORTANT
Cette archive contient le front-end et le raccordement à Supabase Auth. L'authentification ne fonctionnera pas avant configuration d'un projet Supabase et d'un fournisseur d'email. Ne publie pas le site en prétendant que l'authentification est active tant que ces étapes ne sont pas terminées.

1) CRÉER UN PROJET SUPABASE
- Crée un projet sur https://supabase.com/
- Dans Project Settings > API, copie Project URL et la clé anon/publishable.
- Remplace les deux valeurs de config.js. La clé service_role ne doit JAMAIS être placée dans le navigateur.

2) CONFIGURER EMAIL
- Dans Authentication > Providers > Email, active Email.
- Active la confirmation d'adresse email.
- Configure le modèle d'email pour envoyer un code OTP (variable {{ .Token }}) et configure SMTP personnalisé pour une livraison fiable en production.
- Dans Authentication > URL Configuration, ajoute l'URL de ton site Netlify aux Site URL et Redirect URLs.
- Le flux utilise email + mot de passe puis le code email OTP pour confirmer l'inscription. Teste le modèle d'email et le délai d'expiration du code.

3) COMPTE ADMIN eziosen009@gmail.com
- Crée d'abord ce compte via l'inscription du site et confirme son email.
- Dans Supabase Dashboard > Authentication > Users, vérifie que l'adresse correspond bien.
- Attribue le rôle dans app_metadata avec un mécanisme de confiance (par exemple un script serveur utilisant la clé service_role conservée en secret, ou une opération via un outil d'administration de confiance). Valeur : {"role":"admin"}.
- Ne donne pas ce rôle depuis le navigateur et ne te contente jamais de vérifier l'adresse email dans le front-end. L'interface demande à la fois l'adresse spécifiée et le rôle admin côté serveur.

4) SÉCURITÉ ADMIN EN PRODUCTION
La console admin est volontairement informative et ne propose pas encore les actions réelles. Pour bannir/promouvoir des comptes, consulter les journaux IP ou déclencher un arrêt d'urgence, crée des Supabase Edge Functions ou un backend. Chaque requête doit vérifier la session, app_metadata.role == "admin", valider les paramètres et écrire un audit log. La clé service_role doit rester uniquement dans les secrets serveur.
Pour les adresses IP, limite la collecte et l'accès à ce qui est nécessaire, informe les utilisateurs et définis une durée de conservation. N'affiche pas les IP publiquement.
L'arrêt à distance doit être une fonction serveur contrôlée, avec confirmation, journalisation et mécanisme de récupération. Le front-end seul ne peut pas arrêter le serveur.

5) DÉPLOIEMENT NETLIFY
- Décompresse le dossier.
- Configure Supabase et teste localement avec un serveur statique.
- Dépose le contenu du dossier dans Netlify.
- Ajoute l'URL Netlify dans les Redirect URLs Supabase.
- Teste inscription, email OTP, connexion, déconnexion et accès non-admin.
- Ce projet n'a pas de backend Netlify Functions pour la modération : les actions admin réelles ne sont pas activées.

FICHIERS
index.html — interface
styles.css — thème noir/rouge
config.js — URL et clé publique Supabase à renseigner
app.js — flux auth Supabase
supabase-admin-notes.sql — notes de sécurité
assets/nexus-shadow-maquette.png — visuel fourni


MODULE NEXUS LOOKUP
- Une section LOOKUP est accessible depuis le menu latéral / menu hamburger.
- Domaine : ouvre ICANN Lookup avec le domaine saisi.
- IP : ouvre VirusTotal sur la recherche d’adresse IP.
- Pseudo : ouvre une recherche web publique.
- Email : ouvre Have I Been Pwned pour vérifier sa propre adresse email.
- Téléphone : ouvre une recherche web publique.
- Les recherches sont envoyées aux services externes choisis; aucun moteur privé ni API n’est inclus dans le ZIP.
- N’utilise que tes propres données ou celles que tu es autorisé à vérifier. Les résultats externes peuvent varier.
