// Renseigne ces valeurs depuis Supabase > Project Settings > API.
// La clé anon/publishable peut être publique; NE JAMAIS mettre la clé service_role ici.
window.NEXUS_CONFIG = {
  SUPABASE_URL: "https://TON-PROJET.supabase.co",
  SUPABASE_ANON_KEY: "COLLE_ICI_TA_CLE_ANON_PUBLISHABLE"
};