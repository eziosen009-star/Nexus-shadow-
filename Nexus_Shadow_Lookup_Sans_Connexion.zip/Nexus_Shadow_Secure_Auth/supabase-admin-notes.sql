-- À exécuter dans Supabase SQL Editor.
-- Le rôle admin doit être placé dans app_metadata via un outil de confiance côté serveur
-- ou depuis Supabase Dashboard > Authentication > Users > user > app_metadata.
-- Ne pas utiliser user_metadata pour les autorisations : l'utilisateur peut la modifier.
-- Exemple app_metadata de l'utilisateur autorisé : {"role":"admin"}

alter table if exists auth.users enable row level security;
-- L'authentification et la confirmation d'email se configurent aussi dans
-- Authentication > Providers > Email : activer email/password et la confirmation.
-- Pour les opérations d'administration, crée ensuite des Edge Functions qui vérifient
-- auth.jwt()->'app_metadata'->>'role' = 'admin' avant chaque opération.
